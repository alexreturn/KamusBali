package com.example.kamusbali;

public interface FragmentListener {
    void onItemClick(String value);
}
