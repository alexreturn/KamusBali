package com.example.kamusbali;

public interface ListItemListener {
    void onItemClick(int position);
}
