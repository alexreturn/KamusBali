package com.example.kamusbali;

public class Word {
    public String key = "";
    public String value = "";

    public Word(){

    }

    public Word(String key, String value){
        this.key = key;
        this.value = value;
    }
}
